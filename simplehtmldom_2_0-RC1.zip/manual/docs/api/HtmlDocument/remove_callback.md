---
title: remove_callback
---

```php
remove_callback ()
```

Removes the callback set by [`set_callback`](#set_callback).